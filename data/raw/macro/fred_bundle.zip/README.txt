----------------------------------------------------------------
FRED Graph Observations
Federal Reserve Economic Data, Federal Reserve Bank of St. Louis
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-08-31 5:20 pm CDT
----------------------------------------------------------------

------------  ----------------------------------------------------------------------  ------------------------
DGS10         Market Yield on U.S. Treasury Securities at 10-Year Constant Maturity,  Data Updated: 2026-08-31
              Quoted on an Investment Basis, Percent, Daily, Not Seasonally Adjusted
DFII10        Market Yield on U.S. Treasury Securities at 10-Year Constant Maturity,  Data Updated: 2026-08-31
              Quoted on an Investment Basis, Inflation-Indexed, Percent, Daily, Not
              Seasonally Adjusted
T10YIE        10-Year Breakeven Inflation Rate, Percent, Daily, Not Seasonally        Data Updated: 2026-08-31
              Adjusted
DFF           Federal Funds Effective Rate, Percent, Daily, Not Seasonally Adjusted   Data Updated: 2026-08-31
DTWEXBGS      Nominal Broad U.S. Dollar Index, Index Jan 2006=100, Daily, Not         Data Updated: 2026-08-31
              Seasonally Adjusted
DEXCHUS       Chinese Yuan Renminbi to U.S. Dollar Spot Exchange Rate, Chinese Yuan   Data Updated: 2026-08-31
              Renminbi to One U.S. Dollar, Daily, Not Seasonally Adjusted
DCOILBRENTEU  Crude Oil Prices: Brent - Europe, Dollars per Barrel, Daily, Not        Data Updated: 2026-08-26
              Seasonally Adjusted
VIXCLS        CBOE Volatility Index: VIX, Index, Daily, Not Seasonally Adjusted       Data Updated: 2026-08-31
CPIAUCSL      Consumer Price Index for All Urban Consumers: All Items in U.S. City    Data Updated: 2026-08-12
              Average, Index 1982-1984=100, Monthly, Seasonally Adjusted
UNRATE        Unemployment Rate, Percent, Monthly, Seasonally Adjusted                Data Updated: 2026-08-07
PAYEMS        All Employees, Total Nonfarm, Thousands of Persons, Monthly,            Data Updated: 2026-08-07
              Seasonally Adjusted
------------  ----------------------------------------------------------------------  ------------------------

